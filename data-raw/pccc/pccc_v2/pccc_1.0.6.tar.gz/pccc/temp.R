library(devtools)
load_all()

DF <- data.frame(patid = 1:12,
                 dx1 = c("748", 
                         "7480",
                         "7481",
                         "7482",
                         "7483",
                         "7484",
                         "7485",
                         "7486",
                         "7487",
                         "7488",
                         "7489",
                         "748x"))

ccc(data = DF, id = patid, dx_cols = "dx1", icdv = 9)

medicalcoder::comorbidities(data = DF, id.vars = c("patid", "dx1"), icd.codes = "dx1", method = "pccc_v2.0")
medicalcoder::is_icd(DF$dx1)

# Testing for 996.86
DF <- data.frame(patid = 1:12,
                 dx = c("9968", seq(99680, 99689, by = 1), "9968x"))

ccc(data = DF, id = dx, dx_cols = "dx", icdv = 9)

medicalcoder::comorbidities(data = DF, id.vars = c("patid", "dx"), icd.codes = "dx", method = "pccc_v2.0")
medicalcoder::is_icd(DF$dx)


# Testing G80

DF <- data.frame(patid = 1:12,
                 dx = c("G80", paste0("G", seq(800, 809, by = 1)), "G80x"))

ccc(data = DF, id = dx, dx_cols = "dx", icdv = 10)

medicalcoder::comorbidities(data = DF, id.vars = c("patid", "dx"), icd.codes = "dx", method = "pccc_v2.0")
medicalcoder::is_icd(DF$dx)
medicalcoder::lookup_icd_codes("G80")


