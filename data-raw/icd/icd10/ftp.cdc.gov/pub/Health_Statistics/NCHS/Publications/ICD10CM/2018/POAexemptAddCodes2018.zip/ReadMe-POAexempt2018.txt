Description of Present On Admission (POA) files

List of Present On Admission (POA) exempt codes, for FY2018 (36,877 codes).
POAexemptCodes2018.xlsx (Excel spreadsheet)
POAexemptCodes2018.txt (tab delimited text)
These files have three fields, as below.
Order2018: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2018.
POAexemptCode: the ICD-10-CM code that is exempt from POA reporting.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes added to the current FY2018 POA exempt list, from the previous list, to properly match the guidelines (104 codes).
POAexemptAddCodes2018.xlsx (Excel spreadsheet)
POAexemptAddCodes2018.txt (tab delimited text)
These files have three fields, as below.
Order2018: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2018.
POAexemptCode: the ICD-10-CM code that has been added to the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes deleted from the previous POA exempt list, to create the current FY2018 POA exempt list (102 codes).
POAexemptDeleteCodes2018.xlsx (Excel spreadsheet)
POAexemptDeleteCodes2018.txt (tab delimited text)
These files have two fields, as below.
POAexemptCode: the ICD-10-CM code that has been removed from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes revised from the previous POA exempt list, to create the current FY2018 POA exempt list (161 codes, each twice as Revise from and Revise to, for 322 lines).
POAexemptReviseCodes2018.xlsx (Excel spreadsheet)
POAexemptReviseCodes2018.txt (tab delimited text)
These files have four fields, as below.
Order2018: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2018.
Action: "Revise from" and "Revise to" showing the previous title and the new title, respectively.
POAexemptCode: the ICD-10-CM code that has been revised from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.
