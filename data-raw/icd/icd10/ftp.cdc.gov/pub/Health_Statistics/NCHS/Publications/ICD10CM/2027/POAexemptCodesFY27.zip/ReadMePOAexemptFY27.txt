Description of Present On Admission (POA) files

List of Present On Admission (POA) exempt codes, for FY2027 (38,399 codes).
POAexemptCodesFY27.xlsx (Excel spreadsheet)
POAexemptCodesFY27.txt (tab delimited text)
These files have three fields, as below.
Order27: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2027.
POAexemptCode: the ICD-10-CM code that is exempt from POA reporting.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes added to the current FY2027 POA exempt list, from the previous list, to properly match the guidelines (62 codes).
POAexemptAddCodesFY27.xlsx (Excel spreadsheet)
POAexemptAddCodesFY27.txt (tab delimited text)
These files have three fields, as below.
Order27: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2027.
POAexemptCode: the ICD-10-CM code that has been added to the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes deleted from the previous POA exempt list, to create the current FY2027 POA exempt list (12 codes).
POAexemptDeleteCodesFY27.xlsx (Excel spreadsheet)
POAexemptDeleteCodesFY27.txt (tab delimited text)
These files have two fields, as below.
POAexemptCode: the ICD-10-CM code that has been removed from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes revised from the previous POA exempt list, to create the current FY2027 POA exempt list (one code, listed twice as Revise from and Revise to, for two lines).
POAexemptReviseCodesFY27.xlsx (Excel spreadsheet)
POAexemptReviseCodesFY27.txt (tab delimited text)
These files have four fields, as below.
Order27: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2027.
Action: "Revise from:" and "Revise to:" showing the previous title and the new title, respectively.
POAexemptCode: the ICD-10-CM code that has been revised from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.
