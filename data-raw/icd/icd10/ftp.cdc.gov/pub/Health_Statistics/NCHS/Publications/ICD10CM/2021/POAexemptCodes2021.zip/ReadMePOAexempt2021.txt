Description of Present On Admission (POA) files

List of Present On Admission (POA) exempt codes, for FY2021 (37,258 codes).
POAexemptCodes2021.xlsx (Excel spreadsheet)
POAexemptCodes2021.txt (tab delimited text)
These files have three fields, as below.
Order2021: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2021.
POAexemptCode: the ICD-10-CM code that is exempt from POA reporting.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes added to the current FY2021 POA exempt list, from the previous list, to properly match the guidelines (196 codes).
POAexemptAddCodes2021.xlsx (Excel spreadsheet)
POAexemptAddCodes2021.txt (tab delimited text)
These files have three fields, as below.
Order2021: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2021.
POAexemptCode: the ICD-10-CM code that has been added to the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes deleted from the previous POA exempt list, to create the current FY2021 POA exempt list (13 codes).
POAexemptDeleteCodes2021.xlsx (Excel spreadsheet)
POAexemptDeleteCodes2021.txt (tab delimited text)
These files have two fields, as below.
POAexemptCode: the ICD-10-CM code that has been removed from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes revised from the previous POA exempt list, to create the current FY2021 POA exempt list (43 codes, each twice as Revise from and Revise to, for 86 lines).
POAexemptReviseCodes2021.xlsx (Excel spreadsheet)
POAexemptReviseCodes2021.txt (tab delimited text)
These files have four fields, as below.
Order2021: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2021.
Action: "Revise from" and "Revise to" showing the previous title and the new title, respectively.
POAexemptCode: the ICD-10-CM code that has been revised from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.
