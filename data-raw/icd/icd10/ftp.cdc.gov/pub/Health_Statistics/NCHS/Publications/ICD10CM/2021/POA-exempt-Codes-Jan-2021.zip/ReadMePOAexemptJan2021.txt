Description of Present On Admission (POA) files

List of Present On Admission (POA) exempt codes, for Jan. 2021 (37,260 codes).
POAexemptCodes2021.xlsx (Excel spreadsheet)
POAexemptCodes2021.txt (tab delimited text)
These files have three fields, as below.
OrdJan2021: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for Jan. 2021.
POAexemptCode: the ICD-10-CM code that is exempt from POA reporting.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes added to the current FY2021 POA exempt list, from the previous list, to properly match the guidelines (2 codes).
POAexemptAddCodesJan2021.xlsx (Excel spreadsheet)
POAexemptAddCodes2021.txt (tab delimited text)
These files have three fields, as below.
OrdJan2021: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for Jan. 2021.
POAexemptCode: the ICD-10-CM code that has been added to the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

No codes have been deleted from the previous POA exempt list, and no codes have been revised from the previous POA exempt list, so there are no files to identify such potential changes with this update. 
